# LIMEN-TED freeze execution / receipt protocol v0.1

The six candidate pairs are **not frozen yet**.

Use the previously generated `LIMEN_TED_SEXTPAIR_EXEC_v0.1` in an
internet-enabled environment with Java and Maven.

## Execution

```bash
unzip LIMEN_TED_SEXTPAIR_EXEC_v0.1.zip
cd LIMEN_TED_SEXTPAIR_EXEC_v0.1
bash run_all.sh
```

The run must use:
- official OP-TED eForms SDK tag `1.13.3`;
- `schematrons/static/complete-validation.sch`;
- phase `eforms-16`;
- `ph-schematron-pure` 8.0.3 or later, or the official TED CVS.

Do not edit XML after validation.

## Receipt assembly

Copy the 12 XML/SVRL pair files into one directory using these exact names:

- `BT106_VALID.xml`, `BT106_MUTANT.xml`, `BT106_VALID.svrl`, `BT106_MUTANT.svrl`
- `BT19_VALID.xml`, `BT19_MUTANT.xml`, `BT19_VALID.svrl`, `BT19_MUTANT.svrl`
- `BT95_VALID.xml`, `BT95_MUTANT.xml`, `BT95_VALID.svrl`, `BT95_MUTANT.svrl`
- `BT50_VALID.xml`, `BT50_MUTANT.xml`, `BT50_VALID.svrl`, `BT50_MUTANT.svrl`
- `BT51_VALID.xml`, `BT51_MUTANT.xml`, `BT51_VALID.svrl`, `BT51_MUTANT.svrl`
- `BT57_VALID.xml`, `BT57_MUTANT.xml`, `BT57_VALID.svrl`, `BT57_MUTANT.svrl`

Then run:

```bash
python verify_receipt.py <directory>
```

A pair freezes iff:

`valid ERROR = 0`
AND
`mutant target ERROR >= 1`
AND
`mutant unexpected ERROR = 0`.

The verifier writes `LIMEN_TED_FREEZE_RECEIPT.json`.

A failed candidate is rejected; its expected label is not repaired post hoc.
