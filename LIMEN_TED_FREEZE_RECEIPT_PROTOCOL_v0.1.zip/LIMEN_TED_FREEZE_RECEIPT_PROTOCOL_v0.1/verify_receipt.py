#!/usr/bin/env python3
from pathlib import Path
from lxml import etree
import hashlib, json, sys

SVRL = {"svrl":"http://purl.oclc.org/dsdl/svrl"}
PAIRS = {
 "BT106":"BR-BT-00106-0022",
 "BT19":"BR-BT-00019-0062",
 "BT95":"BR-BT-00095-0022",
 "BT50":"BR-BT-00050-0052",
 "BT51":"BR-BT-00051-0052",
 "BT57":"BR-BT-00057-0022",
}

if len(sys.argv) != 2:
    print("Usage: python verify_receipt.py <execution-output-directory>")
    sys.exit(2)

d=Path(sys.argv[1])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def errors(p):
    tree=etree.parse(str(p))
    out=[]
    for x in tree.xpath("//svrl:failed-assert",namespaces=SVRL):
        role=(x.get("role") or x.get("flag") or "").upper()
        if role=="ERROR":
            out.append({
                "id":x.get("id"),
                "location":x.get("location"),
                "test":x.get("test"),
                "text":" ".join("".join(x.itertext()).split())
            })
    return out

result={"pair_results":{}, "files_sha256":{}, "frozen_pairs":0, "all_six_frozen":False}
missing=[]

for p,target in PAIRS.items():
    files={
      "valid_xml":d/f"{p}_VALID.xml",
      "mutant_xml":d/f"{p}_MUTANT.xml",
      "valid_svrl":d/f"{p}_VALID.svrl",
      "mutant_svrl":d/f"{p}_MUTANT.svrl",
    }
    for k,f in files.items():
        if not f.exists(): missing.append(str(f))
        else: result["files_sha256"][f.name]=sha(f)
    if any(not f.exists() for f in files.values()):
        continue

    ve=errors(files["valid_svrl"])
    me=errors(files["mutant_svrl"])
    hits=[e for e in me if e["id"]==target]
    unexpected=[e for e in me if e["id"]!=target]
    accepted=(len(ve)==0 and len(hits)>=1 and len(unexpected)==0)
    result["pair_results"][p]={
      "target_rule":target,
      "valid_blocking_errors":len(ve),
      "mutant_blocking_errors":len(me),
      "target_hits":len(hits),
      "unexpected_errors":len(unexpected),
      "freeze_accepted":accepted,
      "valid_error_list":ve,
      "mutant_error_list":me
    }

result["missing_files"]=missing
result["frozen_pairs"]=sum(1 for x in result["pair_results"].values() if x["freeze_accepted"])
result["all_six_frozen"]=(not missing and result["frozen_pairs"]==6)
out=d/"LIMEN_TED_FREEZE_RECEIPT.json"
out.write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result,indent=2))
print("\nReceipt:", out)
sys.exit(0 if result["all_six_frozen"] else 1)
