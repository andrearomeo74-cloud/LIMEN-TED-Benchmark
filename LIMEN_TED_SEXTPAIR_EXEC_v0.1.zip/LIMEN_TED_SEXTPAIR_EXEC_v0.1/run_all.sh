#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 scripts/prepare_pairs.py
SCH="work/eForms-SDK-1.13.3/schematrons/static/complete-validation.sch";OUT="work/svrl";mkdir -p "$OUT"
mvn -q -DskipTests compile exec:java \
-Dexec.args="$SCH work/xml/BT106_VALID.xml work/xml/BT106_MUTANT.xml work/xml/BT19_VALID.xml work/xml/BT19_MUTANT.xml work/xml/BT95_VALID.xml work/xml/BT95_MUTANT.xml work/xml/BT50_VALID.xml work/xml/BT50_MUTANT.xml work/xml/BT51_VALID.xml work/xml/BT51_MUTANT.xml work/xml/BT57_VALID.xml work/xml/BT57_MUTANT.xml $OUT"
python3 scripts/analyze_svrl.py
