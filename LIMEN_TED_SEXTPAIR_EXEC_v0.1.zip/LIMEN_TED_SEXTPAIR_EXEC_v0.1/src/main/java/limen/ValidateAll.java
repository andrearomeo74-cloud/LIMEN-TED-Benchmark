package limen;
import com.helger.schematron.pure.SchematronResourcePure;
import org.w3c.dom.Document;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import java.io.File;
public class ValidateAll {
 static void write(Document d,File f)throws Exception{Transformer t=TransformerFactory.newInstance().newTransformer();t.transform(new DOMSource(d),new StreamResult(f));}
 static void validate(File sch,File xml,File svrl)throws Exception{
  SchematronResourcePure r=SchematronResourcePure.fromFile(sch);r.setPhase("eforms-16");
  if(!r.isValidSchematron())throw new IllegalStateException("Invalid Schematron");
  Source s=new StreamSource(xml);Document d=r.applySchematronValidation(s);
  if(d==null)throw new IllegalStateException("No SVRL: "+xml);write(d,svrl);
 }
 public static void main(String[] a)throws Exception{
  if(a.length!=14){System.err.println("Need 14 args");System.exit(2);}
  File sch=new File(a[0]),out=new File(a[13]);out.mkdirs();
  String[] n={"BT106_VALID","BT106_MUTANT","BT19_VALID","BT19_MUTANT","BT95_VALID","BT95_MUTANT",
  "BT50_VALID","BT50_MUTANT","BT51_VALID","BT51_MUTANT","BT57_VALID","BT57_MUTANT"};
  for(int i=0;i<12;i++)validate(sch,new File(a[i+1]),new File(out,n[i]+".svrl"));
 }
}
