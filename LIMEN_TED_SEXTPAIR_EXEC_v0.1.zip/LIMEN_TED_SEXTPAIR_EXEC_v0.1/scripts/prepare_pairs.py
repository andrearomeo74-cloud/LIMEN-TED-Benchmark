#!/usr/bin/env python3
from pathlib import Path
from lxml import etree
import urllib.request, zipfile, shutil, hashlib, json
BASE=Path(__file__).resolve().parent.parent
WORK=BASE/"work"; XML=WORK/"xml"; XML.mkdir(parents=True,exist_ok=True)
SDK_URL="https://github.com/OP-TED/eForms-SDK/archive/refs/tags/1.13.3.zip"
BASELINE_URL="https://raw.githubusercontent.com/OP-TED/eForms-SDK/refs/tags/1.13.3/examples/notices/cn_24_minimal.xml"
SDK_ZIP=WORK/"eforms-sdk-1.13.3.zip"; SDK_DIR=WORK/"eForms-SDK-1.13.3"
if not SDK_DIR.exists():
 urllib.request.urlretrieve(SDK_URL,SDK_ZIP)
 with zipfile.ZipFile(SDK_ZIP) as z:z.extractall(WORK)
BASELINE=XML/"OFFICIAL_BASELINE.xml"; urllib.request.urlretrieve(BASELINE_URL,BASELINE)
NS={"cn":"urn:oasis:names:specification:ubl:schema:xsd:ContractNotice-2",
"cac":"urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
"cbc":"urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"}
def parse(p):return etree.parse(str(p),etree.XMLParser(remove_blank_text=False))
def write(t,p):t.write(str(p),encoding="utf-8",xml_declaration=True,pretty_print=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lot="/cn:ContractNotice/cac:ProcurementProjectLot[cbc:ID/@schemeName='Lot']"
lot_tp=lot+"/cac:TenderingProcess"; lot_proj=lot+"/cac:ProcurementProject"
b=parse(BASELINE)
assert b.xpath("string(/cn:ContractNotice/cac:TenderingProcess/cbc:ProcedureCode)",namespaces=NS)=="open"
assert len(b.xpath(lot_proj+"/cac:ContractExtension",namespaces=NS))==0
for x in ("BT106","BT19","BT95","BT50","BT51","BT57"):shutil.copy2(BASELINE,XML/f"{x}_VALID.xml")

# BT106
t=parse(BASELINE);n=t.xpath("/cn:ContractNotice/cac:TenderingProcess/cac:ProcessJustification/cbc:ProcessReasonCode[@listName='accelerated-procedure']",namespaces=NS)[0]
p=n.getparent();p.remove(n)
if len(p)==0 and not(p.text or "").strip():p.getparent().remove(p)
write(t,XML/"BT106_MUTANT.xml")

# BT19
t=parse(BASELINE);tp=t.xpath(lot_tp,namespaces=NS)[0];s=tp.xpath("./cbc:SubmissionMethodCode[@listName='esubmission']",namespaces=NS)[0]
pj=etree.Element("{%s}ProcessJustification"%NS["cac"]);pr=etree.SubElement(pj,"{%s}ProcessReasonCode"%NS["cbc"])
pr.set("listName","no-esubmission-justification");pr.text="phy-mod";s.addnext(pj);write(t,XML/"BT19_MUTANT.xml")

# BT95
t=parse(BASELINE);terms=t.xpath(lot+"/cac:TenderingTerms",namespaces=NS)[0];fund=terms.xpath("./cbc:FundingProgramCode",namespaces=NS)[0]
d=etree.Element("{%s}RecurringProcurementDescription"%NS["cbc"]);d.text="This procurement is expected to recur.";fund.addnext(d);write(t,XML/"BT95_MUTANT.xml")

def shortlist(field,value,out):
 t=parse(BASELINE);tp=t.xpath(lot_tp,namespaces=NS)[0]
 sh=etree.Element("{%s}EconomicOperatorShortList"%NS["cac"]);n=etree.SubElement(sh,"{%s}%s"%(NS["cbc"],field));n.text=value
 a=tp.xpath("./cac:OpenTenderEvent | ./cac:AuctionTerms | ./cac:FrameworkAgreement | ./cac:ContractingSystem",namespaces=NS)
 (a[0].addprevious(sh) if a else tp.append(sh));write(t,XML/out)
shortlist("MinimumQuantity","3","BT50_MUTANT.xml")
shortlist("MaximumQuantity","5","BT51_MUTANT.xml")

# BT57: materialize ContractExtension/Renewal/Period and add only the BT-57 business field.
# BT-58 MaximumNumberNumeric is deliberately absent.
t=parse(BASELINE);proj=t.xpath(lot_proj,namespaces=NS)[0]
ce=etree.Element("{%s}ContractExtension"%NS["cac"])
renew=etree.SubElement(ce,"{%s}Renewal"%NS["cac"])
period=etree.SubElement(renew,"{%s}Period"%NS["cac"])
desc=etree.SubElement(period,"{%s}Description"%NS["cbc"]);desc.text="The contract may be renewed under the stated conditions."
# ContractExtension is placed after PlannedPeriod if present, otherwise before RealizedLocation/other later aggregates.
planned=proj.xpath("./cac:PlannedPeriod",namespaces=NS)
if planned: planned[-1].addnext(ce)
else:
 anchors=proj.xpath("./cac:RealizedLocation | ./cac:ProcurementAdditionalType",namespaces=NS)
 (anchors[0].addprevious(ce) if anchors else proj.append(ce))
write(t,XML/"BT57_MUTANT.xml")

report={"sdk":"1.13.3","phase":"eforms-16","procedure":"open",
"pairs":{
"BT106":{"target":"BR-BT-00106-0022"},"BT19":{"target":"BR-BT-00019-0062"},
"BT95":{"target":"BR-BT-00095-0022"},"BT50":{"target":"BR-BT-00050-0052"},
"BT51":{"target":"BR-BT-00051-0052"},
"BT57":{"target":"BR-BT-00057-0022","predeclared_expected_error_set":["BR-BT-00057-0022"],
"mutation":"insert BT-57 Renewal Description while BT-58 MaximumNumberNumeric remains absent",
"structural_containers":"ContractExtension/Renewal/Period"}
},
"hashes":{p.name:sha(p) for p in sorted(XML.glob("*.xml"))}}
(WORK/"PREPARE_REPORT.json").write_text(json.dumps(report,indent=2),encoding="utf-8");print(json.dumps(report,indent=2))
