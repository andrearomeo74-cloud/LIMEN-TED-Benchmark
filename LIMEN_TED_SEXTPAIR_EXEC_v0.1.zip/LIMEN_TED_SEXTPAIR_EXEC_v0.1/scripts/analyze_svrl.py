#!/usr/bin/env python3
from pathlib import Path
from lxml import etree
import json,sys
B=Path(__file__).resolve().parent.parent;O=B/"work"/"svrl";NS={"svrl":"http://purl.oclc.org/dsdl/svrl"}
P={"BT106":"BR-BT-00106-0022","BT19":"BR-BT-00019-0062","BT95":"BR-BT-00095-0022",
"BT50":"BR-BT-00050-0052","BT51":"BR-BT-00051-0052","BT57":"BR-BT-00057-0022"}
def err(p):
 t=etree.parse(str(p));a=[]
 for x in t.xpath("//svrl:failed-assert",namespaces=NS):
  if(x.get("role")or x.get("flag")or"").upper()=="ERROR":
   a.append({"id":x.get("id"),"location":x.get("location"),"text":" ".join("".join(x.itertext()).split())})
 return a
R={}
for n,target in P.items():
 ve=err(O/f"{n}_VALID.svrl");me=err(O/f"{n}_MUTANT.svrl");hit=[x for x in me if x["id"]==target];col=[x for x in me if x["id"]!=target]
 R[n]={"tier":"A_ISOLATED_CANDIDATE","target_rule":target,"valid_error_count":len(ve),"mutant_error_count":len(me),
 "target_hits":len(hit),"collateral_error_count":len(col),"freeze_accepted":len(ve)==0 and len(hit)>=1 and len(col)==0,
 "valid_errors":ve,"mutant_errors":me}
out={"pair_results":R,"frozen_pair_count":sum(v["freeze_accepted"] for v in R.values()),
"all_pairs_accepted":all(v["freeze_accepted"] for v in R.values())}
(B/"work"/"FREEZE_RESULT.json").write_text(json.dumps(out,indent=2),encoding="utf-8");print(json.dumps(out,indent=2))
sys.exit(0 if out["all_pairs_accepted"] else 1)
