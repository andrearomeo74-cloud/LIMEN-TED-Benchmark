# LIMEN-TED v0.2 — Wave 2

Status: PREDECLARED_EXECUTION_PENDING.

Wave 2 contains:
- 9 oracle candidate matched pairs (18 XML);
- 8 presentation-layer adversarial cases inherited from already frozen evidence.

All 9 XML candidates are compositions of relations already frozen in v0.1 or Wave 1.
Their exact combined blocking ERROR sets are declared before oracle execution.

The analyzer uses only Python standard-library `xml.etree.ElementTree`; no `lxml`
dependency is required.

Promotion:
- baseline: zero blocking ERROR;
- mutant: exact predeclared blocking ERROR set;
- any unexpected or missing ERROR: REJECT;
- no post-hoc repair.

If all nine oracle candidates promote, the cumulative XML frozen set would reach
18 prior cases + 18 Wave-2 cases = 36 XML cases. Together with the eight
presentation adversarial cases, the v0.2 program reaches the preregistered
44-case target, subject to oracle promotion and later blind-package freeze.
