#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
import json
ROOT=Path(__file__).resolve().parent.parent
ledger=json.loads((ROOT/"PREREGISTERED_WAVE2_LEDGER.json").read_text())
sv=ROOT/"work/svrl"
NS="{http://purl.oclc.org/dsdl/svrl}"
def errs(p):
 root=ET.parse(p).getroot()
 return [n.attrib.get("id") for n in root.iter(NS+"failed-assert") if n.attrib.get("role")=="ERROR"]
rows=[]; promoted=0
for spec in ledger["oracle_pairs"]:
 pid=spec["pair_id"]
 ve=errs(sv/f"{pid}_VALID.svrl"); me=errs(sv/f"{pid}_MUTANT.svrl")
 exp=spec["predeclared_expected_error_set"]
 ok=(ve==[] and sorted(me)==sorted(exp))
 rows.append({"pair_id":pid,"valid_errors":ve,"mutant_errors":me,"expected_errors":exp,"promotion":"PROMOTE" if ok else "REJECT"})
 promoted+=int(ok)
report={"status":"WAVE2_ORACLE_ANALYZED","promoted":promoted,"rejected":len(rows)-promoted,"total":len(rows),"results":rows}
(ROOT/"WAVE2_ORACLE_RESULT.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
