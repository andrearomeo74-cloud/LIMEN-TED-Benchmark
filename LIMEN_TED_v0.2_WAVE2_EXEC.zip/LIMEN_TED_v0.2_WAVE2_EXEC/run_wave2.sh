#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p work
if [ ! -d work/eForms-SDK-1.13.3 ]; then
python3 - <<'PY'
from pathlib import Path
import urllib.request,zipfile
w=Path("work");z=w/"eforms-sdk-1.13.3.zip"
urllib.request.urlretrieve("https://github.com/OP-TED/eForms-SDK/archive/refs/tags/1.13.3.zip",z)
with zipfile.ZipFile(z) as q:q.extractall(w)
PY
fi
SCH="work/eForms-SDK-1.13.3/schematrons/static/complete-validation.sch"
mkdir -p work/svrl
XML_ARGS=$(printf "%s " candidates/xml/*.xml)
mvn -q -DskipTests compile exec:java -Dexec.args="$SCH work/svrl $XML_ARGS"
python3 scripts/analyze_svrl.py
