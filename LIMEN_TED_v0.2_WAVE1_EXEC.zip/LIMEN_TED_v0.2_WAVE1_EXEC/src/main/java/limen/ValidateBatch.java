package limen;
import com.helger.schematron.pure.SchematronResourcePure;
import org.w3c.dom.Document;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import java.io.File;
public class ValidateBatch {
  static void write(Document d, File f) throws Exception {
    Transformer t=TransformerFactory.newInstance().newTransformer();
    t.transform(new DOMSource(d),new StreamResult(f));
  }
  static void validate(File sch, File xml, File svrl) throws Exception {
    SchematronResourcePure r=SchematronResourcePure.fromFile(sch);
    r.setPhase("eforms-16");
    if(!r.isValidSchematron()) throw new IllegalStateException("Invalid Schematron");
    Source s=new StreamSource(xml);
    Document d=r.applySchematronValidation(s);
    if(d==null) throw new IllegalStateException("No SVRL: "+xml);
    write(d,svrl);
  }
  public static void main(String[] a) throws Exception {
    if(a.length < 3) { System.err.println("Usage: <sch> <outdir> <xml...>"); System.exit(2); }
    File sch=new File(a[0]), out=new File(a[1]); out.mkdirs();
    for(int i=2;i<a.length;i++){
      File x=new File(a[i]);
      String n=x.getName().replaceFirst("\\.xml$","");
      validate(sch,x,new File(out,n+".svrl"));
    }
  }
}