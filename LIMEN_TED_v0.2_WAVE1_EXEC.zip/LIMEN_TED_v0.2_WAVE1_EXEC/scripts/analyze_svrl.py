#!/usr/bin/env python3
from pathlib import Path
from lxml import etree
import json, sys, hashlib

ROOT=Path(__file__).resolve().parent.parent
ledger=json.loads((ROOT/"PREREGISTERED_WAVE1_LEDGER.json").read_text())
svrl_dir=ROOT/"work/svrl"
NS={"svrl":"http://purl.oclc.org/dsdl/svrl"}

def errs(p):
    t=etree.parse(str(p))
    out=[]
    for n in t.xpath("//svrl:failed-assert[@role='ERROR']",namespaces=NS):
        out.append(n.get("id"))
    return out

results=[]
promoted=0
for pair in ledger["oracle_pairs"]:
    pid=pair["pair_id"]
    vp=svrl_dir/f"{pid}_VALID.svrl"
    mp=svrl_dir/f"{pid}_MUTANT.svrl"
    if not vp.exists() or not mp.exists():
        results.append({"pair_id":pid,"promotion":"REJECT_MISSING_SVRL"})
        continue
    ve=errs(vp); me=errs(mp); exp=pair["predeclared_expected_error_set"]
    ok=(ve==[] and sorted(me)==sorted(exp))
    results.append({"pair_id":pid,"tier":pair["tier"],"valid_errors":ve,"mutant_errors":me,
                    "expected_errors":exp,"promotion":"PROMOTE" if ok else "REJECT"})
    promoted += int(ok)
report={"status":"WAVE1_ORACLE_ANALYZED","promoted":promoted,"total":len(ledger["oracle_pairs"]),"results":results}
(ROOT/"WAVE1_ORACLE_RESULT.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
