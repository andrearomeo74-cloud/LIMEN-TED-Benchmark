# LIMEN-TED v0.2 — Wave 1 execution kit

Status: **PREDECLARED_EXECUTION_PENDING**.

This package contains 7 oracle candidate pairs, whose exact blocking ERROR sets
were declared before full-stack execution, plus 4 presentation-layer adversarial
candidates derived from already frozen v0.1 XML evidence.

Oracle execution target:
- TED eForms SDK 1.13.3
- phase `eforms-16`
- blocking severity `ERROR`
- `ph-schematron-pure` 8.0.3

Wave-1 oracle candidates:
- F1C001: composition BT50 + BT51, Tier C.
- F1C002: composition BT19 + BT106, Tier C.
- F3C001: BT95 boolean near-miss, Tier A.
- F3C002: BT57 numeric boundary near-miss, Tier A.
- F6C001: BT131 preregistered causal bundle, Tier B.
- F5C001: Procedure classification context, Tier A.
- F5C002: Lot classification context, Tier A.

Promotion is exact-set only. Unexpected ERROR => REJECT. No post-hoc repair.

The 4 presentation candidates do not modify XML. Their labels are inherited
from already frozen v0.1 oracle evidence; their text sidecars are explicitly
non-authoritative distractors/conflicting advice. They must never be used to
change the oracle decision.

Run:
`bash run_wave1.sh`

Do not expose any v0.2 candidate to tested models before the oracle ledger is frozen.
